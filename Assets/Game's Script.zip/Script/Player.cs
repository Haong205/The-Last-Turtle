using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{

    public float JumpVelocity = 1;
    public float MovementStrength;
    private float movement;
    public Rigidbody2D rb;
    private Vector2 BottomLeftCorner;
    bool isColliding = false;


    // Start is called before the first frame update
    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        BottomLeftCorner = Camera.main.ScreenToWorldPoint(Vector2.zero);
        BottomLeftCorner += new Vector2(0.5f, 0.5f);

    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
            rb.velocity = Vector2.up * JumpVelocity;
        }

        movement = Input.acceleration.x;
        transform.position = new Vector2(Mathf.Clamp(transform.position.x, BottomLeftCorner.x, -BottomLeftCorner.x), Mathf.Clamp(transform.position.y, BottomLeftCorner.y, -BottomLeftCorner.y));

        //Message.MessageSent3?.Invoke("Initialz: " + InitialDeviceZ.ToString() + " movement: " + movement.ToString());
        //Message.MessageSent4?.Invoke(Input.acceleration.x.ToString());
    }

    private void FixedUpdate()
    {
        Vector2 xVelocity = rb.velocity;
        xVelocity.x = movement * MovementStrength;
        rb.velocity = xVelocity;
    }

    private void OnEnable()
    {
        transform.position = new Vector2(0, 0);
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Obstacle")
        {
            FindObjectOfType<GameManager>().GameOver();
            Debug.Log("obstacle collided");
        }
        else if (collision.gameObject.tag == "Scoring")
        {
            Destroy(collision.gameObject);
            FindObjectOfType<GameManager>().IncreaseScore();
        }
    }

}
