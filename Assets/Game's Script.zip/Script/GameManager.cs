using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    private int score;
    public Player player;
    public TMP_Text ScoreText;
    public GameObject PlayButton;
    public GameObject gameOver;
    public GameObject StartText;
    public bool scored = false;

    private void Awake()
    {
        Pause();
        Application.targetFrameRate = 60;
    }

    private void Start()
    {
        gameOver.SetActive(false);
        StartText.SetActive(true);
        PlayButton.SetActive(true);
    }

    public void GameOver()
    {
        Pause();
        gameOver.SetActive(true);
        PlayButton.SetActive(true);
    }

    private void Update()
    {
        Message.MessageSent4?.Invoke(score.ToString());
    }

    public void Play()
    {
        PlayButton.SetActive(false);
        gameOver.SetActive(false);
        StartText.SetActive(false);

        score = 0;
        ScoreText.text = "Score: " + score.ToString();

        Time.timeScale = 1;
        player.enabled = true;

        branch[] branches = FindObjectsOfType<branch>();
        Scorer[] scores = FindObjectsOfType<Scorer>();
        for (int i = 0; i < branches.Length; i++)
            Destroy(branches[i].gameObject);
        for (int i = 0; i < scores.Length; i++)
            Destroy(scores[i].gameObject);

    }

    public void IncreaseScore()
    {
        if (scored)
            return;
        scored = true;
        Debug.Log(score.ToString());
        score++;
        ScoreText.text = "Score: " + score.ToString();
    }

    public void Pause()
    {
        player.enabled = false;
        Time.timeScale = 0;
    }



}
