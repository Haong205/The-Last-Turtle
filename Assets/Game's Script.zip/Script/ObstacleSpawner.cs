using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleSpawner : MonoBehaviour
{
    public GameObject[] LeftBranch;
    public GameObject[] RightBranch;
    public GameObject score;
    public float maxtime = 2f;
    private float timer = 0;
    private float xRange = 1.8f;
    public float yRange;
    public float speed;
    public float ObstacleDis;

    // Update is called once per frame

    void Update()
    {
        if(timer > maxtime)
        {
            float posx = Random.Range(-xRange, xRange);
            if (posx > -xRange*.80f)
            {
                GameObject newLeftBranch = Instantiate(LeftBranch[Random.Range(0, LeftBranch.Length)]);
                newLeftBranch.transform.position = transform.position + new Vector3(posx - ObstacleDis / 2, Random.Range(0, yRange), 0);
            }

            if (posx < xRange*.80f)
            {
                GameObject newRightBranch = Instantiate(RightBranch[Random.Range(0, RightBranch.Length)]);
                newRightBranch.transform.position = transform.position + new Vector3(posx + ObstacleDis / 2, Random.Range(0, yRange), 0);
            }

            GameObject newScore = Instantiate(score);
            newScore.transform.position = transform.position + new Vector3(posx, 1, 0);
            FindObjectOfType<GameManager>().scored = false;

            timer = 0;
        }

        timer += Time.deltaTime;

        Message.MessageSent1?.Invoke(xRange.ToString());
    }
}
