using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;


public static class Message
{
    public static Action<string> MessageSent1;
    public static Action<string> MessageSent2;
    public static Action<string> MessageSent3;
    public static Action<string> MessageSent4;
}
